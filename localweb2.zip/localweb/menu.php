
<?php
echo '<table class="menu"><tr>
<th><a href="index.php">Home</a></th>
<th><a href="lost.php">Lookup Lost Items</a></th>
<th><a href="found.php">Lookup Found Items</a></th>
<th><a href="addLost.php">Add Lost Items</a></th>
<th><a href="addFound.php">Add Found Items</a></th>
<th><a href="admin.php">Admin</a></th></table>';
?>