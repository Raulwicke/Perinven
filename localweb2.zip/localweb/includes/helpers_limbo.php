<style><?php include "limbostyles.css"; ?></style>

<?php
$debug = true;
function show_records($dbc,$timeframe,$id){
			echo "<h4>If you lost or found something, you're in luck: this is the place to report it.</h4>";
			echo "<br>";
			echo '<form method="POST">' ;
		echo "<p>Reported in the last <select name='timeframe' onchange='this.form.submit()'>
				<option value='1753-01-01'>All</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 DAY)'>1 day ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -7 DAY)'>1 week ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 MONTH)'>1 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -3 MONTH)'>3 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 YEAR)'>1 year ago</option>
				</select></p>" ;
  		echo '</form>' ;
			echo '<div class="datagrid"><table>
           <thead>
           <tr>
           <th>Date/Time</TH>
			<TH>Status</TH> 
			<TH>Stuff</TH>
			</TR>
            </thead>';
		$query = 'Select id, description, create_date, status from stuff where create_date>='.$timeframe.' AND WHERE id = '. $id .' order by create_date desc';
		# Execute the query
		$results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		if($results)
		{ 
            echo '<tbody>';
            # For each row result, generate a table row
			while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
				
                echo '<TR>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
				echo '<TD>' . $row['status'] . '</TD>' ;
				echo '<TD>' . $row['description'] . '</TD>' ;
				echo '</TR>' ;
                
			}
            echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
	}
function show_link_records($dbc,$timeframe){
			echo "<h4>If you lost or found something, you're in luck: this is the place to report it.</h4>";
			echo "<br>";
			echo '<form method="POST">' ;
		echo "<p>Reported in the last <select name='timeframe' onchange='this.form.submit()'>
				<option value='1753-01-01'>All</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 DAY)'>1 day ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -7 DAY)'>1 week ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 MONTH)'>1 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -3 MONTH)'>3 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 YEAR)'>1 year ago</option>
				</select></p>" ;
  		echo '</form>' ;
			echo '<div class="datagrid"><table>
           <thead>
           <tr>
		   <th>ID Number</TH>
           <th>Date/Time</TH>
			<TH>Status</TH> 
			<TH>Stuff</TH>
			</TR>
            </thead>';
		$query = 'Select id,description, create_date, status from stuff where create_date>='.$timeframe.' order by create_date desc';
		# Execute the query
		$results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		if($results)
		{ 
            echo '<tbody>';
            # For each row result, generate a table row
			while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
				echo '<TR>' ;
				$alink = '<A HREF=show_item.php?id=' . $row['id']
				. '>' . $row['id'] . '</A>' ;
				echo '<TD>' . $alink. '</TD>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
				echo '<TD>' . $row['status'] . '</TD>' ;
				echo '<TD>' . $row['description'] . '</TD>' ;
    			echo '</TR>' ;
			}

            echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
	}
function show_found($dbc){
	echo "<h1>Welcome to Limbo!<br></h1>";
			echo "<h4>You've found something! Thanks for reporting it!</h4>";
			echo '<div class="datagrid"><table>
           <thead>
           <tr>
			<TH>Stuff</TH>
			<TH>Finder</TH>
			<TH>Date</TH>
            <TH>Location</TH>
			</TR>
            </thead>';	
    $query = 'SELECT stuff.description, stuff.create_date, stuff.finder, locations.name
                  FROM stuff, locations 
                  WHERE status = "found" AND
                  locations.location_id = stuff.location_id
                  ORDER BY stuff.create_date desc';
		# Execute the query
		$results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		
		if($results)
		{ 
            
			echo '<tbody>';
            # For each row result, generate a table row
			while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
				echo '<TR>' ;
				echo '<TD>' . $row['description'] . '</TD>' ;
				echo '<TD>' . $row['finder'] . '</TD>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
                echo '<TD>' . $row['name'] . '</TD>' ;
				echo '</TR>' ;
			}
			 echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
	}
function show_lost($dbc){
	echo "<h1>Welcome to Limbo!<br></h1>";
			echo "<h4>You've Lost something! Let's see if we can help you find it!!</h4>";
			echo '<div class="datagrid"><table>
           <thead>
           <tr>
			<TH>Stuff</TH>
			<TH>Owner</TH>
			<TH>Date</TH>
            <TH>Location</TH>
			</TR>
            </thead>';
    $query = 'SELECT s.description, s.create_date, s.owner, l.name
                  FROM stuff as s, locations as l 
                  WHERE status = "lost" AND
                  l.location_id = s.location_id
                  ORDER BY s.create_date desc';
		# Execute the query
		$results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		
		if($results)
		{ 
            
			echo '<tbody>';
            # For each row result, generate a table row
			while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ))
			{
				echo '<TR>' ;
				echo '<TD>' . $row['description'] . '</TD>' ;
				echo '<TD>' . $row['owner'] . '</TD>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
                echo '<TD>' . $row['name'] . '</TD>' ;
				echo '</TR>' ;
			}
			 echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
	}
function check_results($results){
	global $dbc;
	$arrayName = array('Select Location', );

	if (!$results){
		echo "<p> SQL ERROR = ". mysqli_error( $dbc ) . '</p>';
	}
}
function show_lost_form($dbc,$description,$owner,$locations, $room) {
  echo '<form action="addLost.php" method="POST">' ;

  echo '<p>Description/Name: <input type="text" name="description" value="' . $description . '"> </p> ' ;


  echo '<p>Owner Name: <input type="text" name="owner" value="' . $owner . '"></p>' ;

  $sql="SELECT name, location_id FROM locations ORDER BY name";
  echo '<select name="locations" value="">Location</option>';
	foreach ($dbc->query($sql) as $row){
		echo "<option value=$row[location_id]>$row[name]</option>";
	}
  echo "</select>"; 
  
  echo '<p>Room: <input type="text" name="room" value="' . $room . '"></p>' ;

  echo '<p><input type="submit"></p>' ;
  echo '</form>' ;
}


function insert_lost_record($dbc, $description, $owner, $location, $room) {
  $status= 'lost';
  $query = 'INSERT INTO stuff(location_id,description,create_date,update_date,room,owner,finder,status) 
  			VALUES ("' . $location . '","' . $description . '" ,now(),now(), "' . $room . '","' . $owner . ' ",Null, "'. $status . '")' ;

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}
function insert_found_record($dbc, $description, $finder, $location, $room) {
  $status= 'found';
  $query = 'INSERT INTO stuff(location_id,description,create_date,update_date,room,owner,finder,status) 
  			VALUES ("' . $location . '","' . $description . '" ,now(),now(), "' . $room . '",Null,"' . $finder . ' ","'. $status . '")' ;

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}
function show_find_form($dbc,$description,$finder,$locations, $room) {
  echo '<form action="addFound.php" method="POST">' ;

  echo '<p>Description/Name: <input type="text" name="description" value="' . $description . '"> </p> ' ;

  echo '<p>Finder Name: <input type="text" name="finder" value="' . $finder . '"></p>' ;

  $sql="SELECT name, location_id FROM locations ORDER BY name";
  echo '<select name="locations" value="">Location</option>';
	foreach ($dbc->query($sql) as $row){
		echo "<option value=$row[location_id]>$row[name]</option>";
	}
  echo "</select>"; 
  
  echo '<p>Room: <input type="text" name="room" value="' . $room . '"></p>' ;

  echo '<p><input type="submit"></p>' ;
  echo '</form>' ;
}
function show_admin_records($dbc,$timeframe){
		
			echo "<h4>If you lost or found something, you're in luck: this is the place to report it.</h4>";
			echo "<br>";
			echo '<form method="POST">' ;
		echo "<p>Reported in the last <select name='timeframe' onchange='this.form.submit()'>
				<option value='1000-01-01'>All</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 DAY)'>1 day ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -7 DAY)'>1 week ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 MONTH)'>1 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -3 MONTH)'>3 month ago</option>
  				<option value='DATE_ADD(now(), INTERVAL -1 YEAR)'>1 year ago</option>
				</select></p>" ;
  		echo '</form>' ;
			echo '<div class="datagrid"><table>
           <thead>
           <tr>
			<TH>Date/Time</TH>
			<TH>Status</TH>
			<TH>Stuff</TH>
            <th>Edit</th>
			<th>Delete</th>
			</TR>
            </thead>';
		$query = 'Select id, description, create_date, status from stuff where create_date>='.$timeframe.' order by create_date desc';
		# Execute the query
		$results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		
		if($results)
		{ 
             echo '<tbody>';
            # For each row result, generate a table row
			while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
				echo '<TR>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
				echo '<TD>' . $row['status'] . '</TD>' ;
				echo '<TD>' . $row['description'] . '</TD>' ;
				echo '<TD><form action="edit.php" method="GET"><input type="hidden" name="id" value="'. $row['id'] . '"><input type="submit" value="Update" /></form></TD>';
                echo '<TD><form action="delete.php" method="GET"><input type="hidden" name="id" value="'. $row['id'] . '"><input type="submit" value="Delete" /></form></TD>';
                echo '</TR>' ;
			}
			  echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
	}
function show_update_item($dbc,$id) {
    echo '<div> <p style="font-size:32px">Current information on item:</p></div>';
    echo '<div class="datagrid">
           <table>
           <thead>
           <tr>
           
           <th>Date/Time</TH>
			<TH>Stuff</TH>
            <th>Owner</th>
            <th>Finder</th>
            <th>Location</th>
            <th>Room</th>
            <TH>Status</TH> 
			</TR>
            </thead>';
    $query = 'SELECT s.description, s.create_date, s.owner,s.finder,s.status,s.room, l.name FROM stuff as s, locations as l WHERE id ="'.$id.'" AND
                  l.location_id = s.location_id';
    $results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		if($results)
		{
            echo '<tbody>';
            while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
				
                echo '<TR>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
                echo '<TD>' . $row['description'] . '</TD>' ;
                echo '<TD>' . $row['owner'] . '</TD>' ;
                echo '<TD>' . $row['finder'] . '</TD>' ;
				echo '<TD>' . $row['name'] . '</TD>' ;
				echo '<TD>' . $row['room'] . '</TD>' ;
                echo '<TD>' . $row['status'] . '</TD>' ;
				echo '</TR>' ;
                
			}
            echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
}
function show_update_form($dbc, $description, $owner, $locations, $room, $finder, $status) {

 echo '<form index_admin.php method="POST">' ;

  echo '<p>Description/Name: <input type="text" name="description" value="' . $description . '"> </p> ' ;

  echo '<p>Owner Name: <input type="text" name="owner" value="' . $owner . '"></p>' ;

echo '<p>Finder Name: <input type="text" name="finder" value="' . $finder . '"></p>' ;

  $sql="SELECT name, location_id FROM locations ORDER BY name";
  echo '<select name="locations" value="">Location</option>';
	foreach ($dbc->query($sql) as $row){
		echo "<option value=$row[location_id]>$row[name]</option>";
	}
  echo "</select>"; 
  
  echo '<p>Room: <input type="text" name="room" value="' . $room . '"></p>' ;

echo "<p>Status <select name='status'>
				<option value='lost'>Lost</option>
				<option value='found'>Found</option>
				<option value='claimed'>Claimed</option>
				</select></p>" ;
  echo '<p><input type="submit"></p>' ;
  echo '</form>' ;

}
function delete_entry($dbc, $id){
	$query = 'DELETE FROM stuff WHERE id = "'. $id.'";';
		# Execute the query
		 mysqli_query( $dbc , $query ) ;
	header('Location: /index_admin.php');
	
}
function update_record ($dbc,$id, $description , $owner, $locations, $room,$finder,$status){
	$query = 'UPDATE stuff SET location_id =" ' .$locations. ' ", description = "'. $description. '", owner = "' .$owner. '", finder = "'.$finder.'", room = "'.$room.'", status="'.$status.'" WHERE id = "'.$id.'";';
	$results = mysqli_query($dbc, $query);
	check_results($results) ;
	return $results;
}
function show_item_info($dbc,$id) {
    echo '<div> <p style="font-size:32px">Current information on item:</p></div>';
    echo '<div class="datagrid">
           <table>
           <thead>
           <tr>
		   <th>ID Number</TH>
           <th>Date/Time</TH>
			<TH>Stuff</TH>
            <th>Owner</th>
            <th>Finder</th>
            <th>Location</th>
            <th>Room</th>
            <TH>Status</TH> 
			</TR>
            </thead>';
    $query = 'SELECT s.description, s.create_date, s.owner,s.finder,s.status,s.room, l.name, s.id FROM stuff as s, locations as l WHERE id ="'.$id.'" AND
                  l.location_id = s.location_id';
    $results = mysqli_query( $dbc , $query ) ;
		check_results($results);
		if($results)
		{
            echo '<tbody>';
            while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
			{
                echo '<TR>' ;
				echo '<TD>' . $row['id'] . '</TD>' ;
				echo '<TD>' . $row['create_date'] . '</TD>' ;
                echo '<TD>' . $row['description'] . '</TD>' ;
                echo '<TD>' . $row['owner'] . '</TD>' ;
                echo '<TD>' . $row['finder'] . '</TD>' ;
				echo '<TD>' . $row['name'] . '</TD>' ;
				echo '<TD>' . $row['room'] . '</TD>' ;
                echo '<TD>' . $row['status'] . '</TD>' ;
				echo '</TR>' ;
                
			}
            echo '</tbody>';
			# End the table
			echo '</TABLE>';
            echo '</div>';
			mysqli_free_result( $results);
		}
		else{
			echo "Something has gone wrong";
		
		}
}
?>