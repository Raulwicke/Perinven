<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>	
	</head>
<body>
	<div class="add_admin">
	</div>

<?php
	# Create a query to get the number, fname, lname sorted by number
	# Connect to MySQL server and the database
	require( 'includes/connect_limbo.php' ) ;
	# Includes these helper functions
	require( 'includes/helpers_limbo.php' ) ;
	if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) {
	  $first_name = "" ;
	  $last_name = "" ;
	  $email = "" ;
	  $pass ="";
	}

?>
	<h1>Add a New Admin</h1>
<form action="add_admin.php" method="POST">
<table class="login">
<tr>
<td>First Name:</td><td><input type="text" name="first_name"></td>
</tr>
<tr>
<tr>
<td>Last Name:</td><td><input type="text" name="last_name"></td>
</tr>
<tr>
<td>Email:</td><td><input type="text" name="login"></td>
</tr>
<tr>
<td>Password:</td><td><input type="password" name="pass"></td>
</tr>
</table>
    <p><button type="submit" class="button" >Submit</button></p>
</form>
</body>