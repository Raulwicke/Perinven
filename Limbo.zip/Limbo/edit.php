<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>
	</head>
	<body>
<!--Creates Top Menu Bar-->
        <div class="menu">
            <?php include 'menu.php';?>
        </div>
    <?php
# Connect to MySQL server and the database
        require( 'includes/connect_limbo.php' ) ;
# Includes these helper functions
        require( 'includes/helpers_limbo.php' ) ;
    
        echo '<br/>';
#Initializes variables when loading page  
        if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) 
        {
            $description = "" ;
            $owner = "" ;
            $room = "" ;
            $locations ="";
            $finder = "";
            $status= "";
            $id=$_GET["id"];
        }
        else if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
        {
# Initialize an error array.
            $errors = array();
#Creates variables with info from form      
            $id=$_GET["id"];
            if(isset($_POST[ 'description' ]))
            {
                $description = $_POST[ 'description' ] ;
            }
            if(isset($_POST[ 'owner' ]))
            {
                $owner= $_POST['owner'];
            }
            if(isset($_POST[ 'finder' ]))
            {
                $finder= $_POST['finder'];
            }
            if(isset($_POST[ 'room' ]))
            {
                $room = $_POST[ 'room' ] ;
            }
            if(isset($_POST[ 'locations' ]))
            {
                $locations= $_POST['locations'];
            }
            if(isset($_POST[ 'status' ]))
            {
                $status= $_POST['status'];
            }
            
# Check if input is empty
            if ( empty($_POST['description'] ))  
            {
                $errors[] = 'Description' ;
            }
            else 
            {
                $description = trim( $description )  ;
            }
            
            if ( empty( $_POST[ 'owner' ] ) ) 
            {
                $errors[] = 'Owner Name' ;
            }
            else 
            {
                $owner = trim( $owner )  ;
            }
            
            if ( empty( $_POST[ 'room' ] ) ) \
            {
                $errors[] = 'Room' ;
            }
            else 
            {
                $room = trim( $room )  ;
            }
            
            if ( empty( $_POST[ 'locations' ] ) ) 
            {
                $errors[] = 'Locations' ;
            }
            else 
            {
                $locations = trim( $locations )  ;
            }
            
            if ( empty( $_POST[ 'finder' ] ) ) 
            {
                $errors[] = 'Finder' ;
            }
            else 
            {
                $finder = trim( $finder )  ;
            }
            
            if ( empty( $_POST[ 'status' ] ) ) 
            {
                $errors[] = 'status' ;
            }
            else 
            {
                $status = trim( $status )  ;
            }
            
# Report errors.
            if( !empty( $errors ) )
            {
                echo '<p>Error! Please enter a valid  ' ;
                foreach ( $errors as $field ) { echo " - $field " ; }
            }
#Update item with info from form  
            else 
            {
                echo "<p>Success! </p>" ;
                $result = update_record($dbc,$id,$description , $owner, $locations, $room,$finder,$status) ;
            }
        }
# Show the table form for update items
show_update_item($dbc,$id);
# Show the input form for updating items
show_update_form($dbc, $description, $owner, $locations, $room, $finder, $status) ;
#Close the connection
mysqli_close( $dbc ) ;
?>
	</body>
</html>