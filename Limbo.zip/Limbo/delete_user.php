<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>
	</head>
	<body>
<!--Creates Top Menu Bar-->
        <div class="menu">
            <?php include 'menu.php';?>
        </div>
    <?php
# Connect to MySQL server and the database
	   require( 'includes/connect_limbo.php' ) ;
# Includes these helper functions
	   require( 'includes/helpers_limbo.php' ) ;
	
        echo '<br/>';
#Initializes variables when loading page   
        if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) 
        {
            $user_id=$_GET["user_id"];
        }
        else if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
        {
# Initialize an error array.
            $errors = array();
#Creates variables with info from form    
            $user_id=$_GET["user_id"];  
        }
#Executes function to delete specific user  
delete_user($dbc,$user_id);
#Close the connection
mysqli_close( $dbc ) ;
?>
	</body>
</html>