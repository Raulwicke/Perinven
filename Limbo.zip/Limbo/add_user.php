<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>	
	</head>
    <body>
<!--Creates Top Menu Bar-->
        <div class="menu">
            <?php include 'menu.php';?>
        </div>

    <?php
    # Connect to MySQL server and the database
        require( 'includes/connect_limbo.php' ) ;
    # Includes these helper functions
        require( 'includes/helpers_limbo.php' ) ;
    #Initializes variables when loading page
        if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) 
        {
            $first_name = "" ;
            $last_name = "" ;
            $username ="";
            $email = "" ;
            $pass ="";
        }
        else if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
        {
    # Initialize an error array.
            $errors = array();
    #Creates variables with info from form    
            if(isset($_POST[ 'first_name' ]))
            {
                $first_name = $_POST[ 'first_name' ] ;
            }   
            if(isset($_POST[ 'pass' ]))
            {
                $pass= $_POST['pass'];
            }
            if(isset($_POST[ 'last_name' ]))
            {
                $last_name = $_POST[ 'last_name' ] ;
            }  
            if(isset($_POST[ 'login' ]))
            {
                $username = $_POST[ 'login' ] ;
            }
            if(isset($_POST[ 'email' ]))
            {
                $email= $_POST['email'];
            }

    # Check if input is empty
            if ( empty($_POST['first_name'] ))  
            {
                $errors[] = 'First Name' ;
            }
            else 
            {
                $first_name = trim( $first_name )  ;
            }

            if ( empty( $_POST[ 'last_name' ] ) ) 
            {
                $errors[] = 'Last Name' ;
            }
            else 
            {
                $last_name = trim( $last_name )  ;
            }

            if ( empty( $_POST[ 'email' ] ) ) 
            {
                $errors[] = 'Email' ;
            }
            else 
            {
                $email = trim( $email )  ;
            }

            if ( empty( $_POST[ 'login' ] ) ) 
            {
                $errors[] = 'Username' ;
            }
            else 
            {
                $username = trim( $username)  ;
            }

            if ( empty( $_POST[ 'pass' ] ) ) 
            {
                $errors[] = 'Password' ;
            }
            else 
            {
                $pass = trim( $pass )  ;
            }

    # Report errors.
            if( !empty( $errors ) )
            {
                echo '<p>Error! Please enter a valid  ' ;
                foreach ( $errors as $field ) { echo " - $field " ; }
            }
    #Insert admin with info from form  
            else 
            {
                echo "<p>Success! </p>" ;
                $result = insert_admin($dbc, $first_name,$last_name,$username,$email,$pass) ;
            }
        }
    ?>
        <h1>Add a New User</h1>
    <!--Form for adding admin-->
    <form action="add_admin.php" method="POST">
    <table class="login">
    <tr>
    <td>First Name:</td><td><input type="text" name="first_name"></td>
    </tr>
    <tr>
    <tr>
    <td>Last Name:</td><td><input type="text" name="last_name"></td>
    </tr>
    <tr>
    <td>Username(login):</td><td><input type="text" name="login"></td>
    </tr>
    <tr>
    <td>Password:</td><td><input type="password" name="pass"></td>
    </tr>
        <tr>
    <td>Email:</td><td><input type="text" name="email"></td>
    </tr>
    </table>
        <p><button type="submit" class="button" >Submit</button></p>
    </form>
        <a href="menu_admin.php">Admin Menu</a>
    </body>
</html>    