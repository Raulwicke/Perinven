<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>
</head>

<body>
	<div class="menu">
	    <?php include 'menu.php';?>
	</div>
<div class="menu_admin">
</div>
<h1>Admin Menu</h1>
<form action="add_admin.php">
	<button type="submit" class="button">Add Admin
	</button>
</form>
<br>
<br>
<form action="delete_admin.php">
	<button type="submit" class="button">Delete Admin
	</button>
</form>
<br>
<br>
<form action="change_a_pass.php">
	<button type="submit" class="button" >Change Admin password
	</button>
</form>
</body>