<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>
</head>

<body>
	<div class="menu">
	    <?php include 'menu.php';?>
	</div>
<div class="menu_admin">
</div>
<h1>User Menu</h1>
<form action="index_admin.php">
	<button type="submit" class="button" >Show Admin Item List
	</button>
    <br/>
    <br>
    <br/>
</form>
    <form action="add_user.php">
	<button type="submit" class="button">Add User
	</button>
</form>
<br>
<br>
<form action="users.php">
	<button type="submit" class="button"> Users
	</button>
</form>
<br>
<br>
<form action="change_password.php">
	<button type="submit" class="button" >Change password
	</button>
</form>


</body>