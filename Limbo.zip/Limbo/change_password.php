<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>	
	</head>
    <body>
<!--Creates Top Menu Bar-->
        <div class="menu">
            <?php include 'menu.php';?>
        </div>
        <h1>Change Password</h1>
    <?php
# Connect to MySQL server and the database
        require( 'includes/connect_limbo.php' ) ;
# Includes these helper functions
        require( 'includes/helpers_limbo.php' ) ;
 #Initializes variables when loading page
        if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) 
        {
            $username = "" ;
            $password1 ="";
            $password2 = "" ;
        }
        else if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
        {
# Initialize an error array.
            $errors = array();
#Creates variables with info from form
            if(isset($_POST[ 'username' ]))
            {
                $username = $_POST[ 'username' ] ;
            }  
            if(isset($_POST[ 'password1' ]))
            {
                $password1= $_POST['password1'];
            }
            if(isset($_POST[ 'password2' ]))
            {
                $password2 = $_POST[ 'password2' ] ;
            }
    
# Check if input is empty
            if ( empty($_POST['username'] ))  
            {
                $errors[] = 'username' ;
            }
            else 
            {
                $username = trim( $username )  ;
            }
            
            if ( empty( $_POST[ 'password1' ] ) ) 
            {
                $errors[] = 'Password' ;
            }
            else 
            {
                $password1 = trim( $password1 )  ;
            }
            
            if ( empty( $_POST[ 'password2' ] ) ) 
            {
                $errors[] = 'Password Verification' ;
            }
            else 
            {
                $password2 = trim( $password2 )  ;
            }
#Compares both passwords to see if they are  the same
            if (strcmp($password1,$password2)!==0 ) 
            {
                $errors[] = 'Password for both passwords';
                echo 'Passwords does not match';
            }
# Report errors.
            if( !empty( $errors ) )
            {
                echo '<p>Error! Please enter a valid  ' ;
                foreach ( $errors as $field ) { echo " - $field " ; }
            }
            else
            {
#Uses the function validate_username to confirm accurate username
                $check = validate_username($dbc,$username);
#Executed if username is wrong  
                if($check == -1)
                    echo '<P style=color:red>Login failed please try again.</P>' ;
#Executed if username is correct  
                else 
                {
                    echo "<p>Success! </p>" ;
                    $result = change_password($dbc, $username,$password1) ;
                }
            }   
        }
    ?>
    <!--Form for changing password-->	
    <form action="change_password.php" method="POST">
    <table class="login">
    <tr>
    <td>Username(login):</td><td><input type="text" name="username"></td>
    </tr>
    <tr>
    <tr>
    <td>New Password:</td><td><input type="password" name="password1"></td>
    </tr>
    <tr>
    <td>Password Verification</td><td><input type="password" name="password2"></td>
    </tr>
    </table>
        <p><button type="submit" class="button" >Submit</button></p>
    </form>
        <a href="menu_admin.php">Admin Menu</a>
    </body>
</html>