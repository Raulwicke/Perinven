<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Style-Type" content="text/css" /> 
		<title>Limbo.com</title>
		<link href="/library/skin/tool_base.css" type="text/css" rel="stylesheet" media="all" />
		<link href="/library/skin/morpheus-default/tool.css" type="text/css" rel="stylesheet" media="all" />
        <link href="limbostyles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="JavaScript" src="/library/js/headscripts.js"></script>

		
	</head>
	<body>
<!--Creates Top Menu Bar-->
        <div class="menu">
            <?php include 'menu.php';?>
        </div>
        <h1>Admin login</h1>
		
    <?php
# Includes these login functions
        require('limbo_login_tools.php');
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') 
        {
            $login = $_POST['login'] ;
            $pass = $_POST['pass'] ;
#Uses the function validate to confirm accurate login and password
            $check = validate($dbc,$login, $pass) ;
#Executed if login fails      
            if($check == -1)
                echo '<P style=color:red>Login failed please try again.</P>' ;
#Executed if login succeeds
            else
                load('menu_admin.php',$check);
        }
    ?>
    <!--Form for adding admin-->  
    <form action="admin.php" method="POST">
    <table class="login">
    <tr>
    <td>Login:</td><td><input type="text" name="login"></td>
    </tr>
    <tr>
    <td>Password:</td><td><input type="password" name="pass"></td>
    </tr>
    </table>
    <p><button type="submit" class="button" >Submit</button></p>
    </form>
    </body>
</html>

