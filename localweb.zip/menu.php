
<?php
echo '<a href="index.php">Menu</a> -
<a href="lost.php">Lookup Lost Items</a> -
<a href="found.php">Lookup Found Items</a> -
<a href="addLost.php">Add Lost Items</a> -
<a href="addFound.php">Add Found Items</a> -
<a href="admin.php">Admin</a>';
?>